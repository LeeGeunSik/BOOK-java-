package game;

public class UnMovable extends Map {
	public UnMovable() {
	}

}

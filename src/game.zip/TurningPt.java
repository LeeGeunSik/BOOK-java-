package game;

public class TurningPt extends UnMovable{

}
